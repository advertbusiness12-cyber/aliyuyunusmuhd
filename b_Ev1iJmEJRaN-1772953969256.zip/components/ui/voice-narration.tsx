'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Volume2, VolumeX, Play, Pause, SkipForward, X } from 'lucide-react'

interface VoiceNarrationProps {
  currentSection: number
  isEnabled: boolean
  onToggle: () => void
}

// Narration scripts for each section
const narrationScripts = [
  // Intro
  `Welcome to my portfolio! I'm Aliyu Yunus Muhammad, a passionate full-stack web developer. 
   I create interactive and user-friendly applications that blend design with functionality. 
   Use the controller on the right to navigate, or simply scroll down to explore my work.`,
  
  // About
  `Let me tell you a bit about myself. I'm a Computer Science student at Maryam Abacha American University of Nigeria.
   I started my journey in web development in 2022, and since then, I've been building projects that solve real-world problems.
   I specialize in creating chatbots, web applications, and full-stack solutions using modern technologies.`,
  
  // Projects
  `Here are some of my featured projects. First, the Business Assistant Chatbot helps businesses manage customer queries efficiently.
   The LiveChat Bot enables real-time communication between users. And the University FAQ Chatbot helps students get instant answers about admission, fees, and courses.
   Click on any project card to see a live demo and learn more about its features.`,
  
  // Skills
  `My technical skills include HTML, CSS, and JavaScript for frontend development, with 95%, 90%, and 85% proficiency respectively.
   For backend, I work with Python and Flask at 80% proficiency, and I have 85% experience with databases including MySQL and SQLite.
   I consider myself a full-stack developer with 90% proficiency in building complete web applications.`,
  
  // Contact
  `Thank you for visiting my portfolio! If you'd like to work together or have any questions, feel free to reach out.
   You can email me at aliyuyunusmuhammad5@gmail.com or call me at +234 913 247 4502.
   I'm always open to new opportunities and exciting projects. Let's build something amazing together!`,
]

export function VoiceNarration({ currentSection, isEnabled, onToggle }: VoiceNarrationProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [showPanel, setShowPanel] = useState(false)
  const [currentText, setCurrentText] = useState('')
  const [progress, setProgress] = useState(0)
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null)
  const hasNarratedRef = useRef<Set<number>>(new Set())

  // Check if speech synthesis is available
  const isSpeechAvailable = typeof window !== 'undefined' && 'speechSynthesis' in window

  // Stop speech
  const stopSpeech = useCallback(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel()
    }
    setIsPlaying(false)
    setIsPaused(false)
    setProgress(0)
  }, [])

  // Speak text
  const speak = useCallback((text: string, autoPlay = false) => {
    if (!isSpeechAvailable) return

    stopSpeech()
    
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.volume = 0.8
    
    // Try to get a good voice
    const voices = window.speechSynthesis.getVoices()
    const preferredVoice = voices.find(v => 
      v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Microsoft') || v.name.includes('Natural'))
    ) || voices.find(v => v.lang.startsWith('en'))
    
    if (preferredVoice) {
      utterance.voice = preferredVoice
    }

    utterance.onstart = () => {
      setIsPlaying(true)
      setIsPaused(false)
      setCurrentText(text)
    }

    utterance.onend = () => {
      setIsPlaying(false)
      setIsPaused(false)
      setProgress(100)
    }

    utterance.onpause = () => setIsPaused(true)
    utterance.onresume = () => setIsPaused(false)

    // Update progress (approximate)
    const words = text.split(' ').length
    const duration = (words / 150) * 60 * 1000 // ~150 words per minute
    let startTime = Date.now()
    
    const updateProgress = () => {
      if (!isPlaying) return
      const elapsed = Date.now() - startTime
      const newProgress = Math.min((elapsed / duration) * 100, 100)
      setProgress(newProgress)
      if (newProgress < 100 && isPlaying) {
        requestAnimationFrame(updateProgress)
      }
    }
    
    speechRef.current = utterance
    window.speechSynthesis.speak(utterance)
    requestAnimationFrame(updateProgress)
  }, [isSpeechAvailable, stopSpeech])

  // Auto-narrate when section changes (if enabled and not already narrated)
  useEffect(() => {
    if (isEnabled && !hasNarratedRef.current.has(currentSection)) {
      const timer = setTimeout(() => {
        speak(narrationScripts[currentSection], true)
        hasNarratedRef.current.add(currentSection)
      }, 1500) // Delay to let section animation complete
      
      return () => clearTimeout(timer)
    }
  }, [currentSection, isEnabled, speak])

  // Stop speech when disabled
  useEffect(() => {
    if (!isEnabled) {
      stopSpeech()
    }
  }, [isEnabled, stopSpeech])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel()
      }
    }
  }, [])

  const togglePlayPause = () => {
    if (!isSpeechAvailable) return

    if (isPlaying && !isPaused) {
      window.speechSynthesis.pause()
    } else if (isPaused) {
      window.speechSynthesis.resume()
    } else {
      speak(narrationScripts[currentSection])
    }
  }

  const skipToNext = () => {
    stopSpeech()
    // Mark current as narrated so it won't auto-play again
    hasNarratedRef.current.add(currentSection)
  }

  if (!isSpeechAvailable) return null

  return (
    <>
      {/* Main toggle button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 2 }}
        className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2"
      >
        {/* Expanded panel */}
        <AnimatePresence>
          {showPanel && isEnabled && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              className="glass rounded-xl p-4 mb-2 w-64"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">Voice Guide</span>
                <button
                  onClick={() => setShowPanel(false)}
                  className="p-1 rounded-full hover:bg-muted/50 transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1 rounded-full bg-muted/30 mb-3 overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  style={{ width: `${progress}%` }}
                  transition={{ duration: 0.1 }}
                />
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-3">
                <motion.button
                  onClick={togglePlayPause}
                  className="p-3 rounded-full glass hover:bg-primary/20 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isPlaying && !isPaused ? (
                    <Pause className="w-5 h-5 text-primary" />
                  ) : (
                    <Play className="w-5 h-5 text-primary" />
                  )}
                </motion.button>

                <motion.button
                  onClick={skipToNext}
                  className="p-2 rounded-full glass hover:bg-muted/50 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  disabled={!isPlaying}
                >
                  <SkipForward className={`w-4 h-4 ${isPlaying ? 'text-foreground' : 'text-muted-foreground/50'}`} />
                </motion.button>
              </div>

              {/* Status */}
              <p className="text-xs text-muted-foreground text-center mt-3">
                {isPlaying ? (isPaused ? 'Paused' : 'Speaking...') : 'Click play to hear about this section'}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Toggle button */}
        <motion.button
          onClick={() => {
            if (isEnabled) {
              setShowPanel(!showPanel)
            } else {
              onToggle()
              setShowPanel(true)
            }
          }}
          className={`p-3 rounded-full glass transition-colors ${
            isEnabled ? 'hover:bg-primary/20 neon-border' : 'hover:bg-muted/50'
          }`}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          data-cursor-hover
        >
          {isEnabled ? (
            <Volume2 className="w-5 h-5 text-primary" />
          ) : (
            <VolumeX className="w-5 h-5 text-muted-foreground" />
          )}
        </motion.button>

        {/* Enable hint */}
        <AnimatePresence>
          {!isEnabled && (
            <motion.span
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="text-xs text-muted-foreground whitespace-nowrap absolute right-14 top-1/2 -translate-y-1/2"
            >
              Enable voice guide
            </motion.span>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Speaking indicator */}
      <AnimatePresence>
        {isPlaying && isEnabled && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-40 glass px-4 py-2 rounded-full flex items-center gap-3"
          >
            {/* Sound wave animation */}
            <div className="flex items-center gap-0.5">
              {[...Array(4)].map((_, i) => (
                <motion.div
                  key={i}
                  className="w-1 bg-primary rounded-full"
                  animate={{
                    height: ['8px', '16px', '8px'],
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: Infinity,
                    delay: i * 0.1,
                  }}
                />
              ))}
            </div>
            <span className="text-xs text-primary font-medium">Voice Guide Active</span>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
