'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronUp, ChevronDown } from 'lucide-react'

interface PSControllerProps {
  currentSection: number
  totalSections: number
  onNavigate: (section: number) => void
}

export function PSController({ currentSection, totalSections, onNavigate }: PSControllerProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [dragY, setDragY] = useState(0)
  const [showHint, setShowHint] = useState(true)
  const containerRef = useRef<HTMLDivElement>(null)
  const startYRef = useRef(0)
  const lastNavigationRef = useRef(0)

  // Hide hint after interaction
  useEffect(() => {
    if (isDragging) {
      setShowHint(false)
    }
  }, [isDragging])

  // Hide hint after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => setShowHint(false), 5000)
    return () => clearTimeout(timer)
  }, [])

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    setIsDragging(true)
    startYRef.current = e.clientY
    setDragY(0)
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
  }, [])

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging) return
    
    const deltaY = e.clientY - startYRef.current
    const clampedDelta = Math.max(-100, Math.min(100, deltaY))
    setDragY(clampedDelta)

    // Navigate when threshold is reached
    const now = Date.now()
    if (now - lastNavigationRef.current > 500) { // Debounce navigation
      if (clampedDelta < -50 && currentSection > 0) {
        // Pull up = go to previous section
        onNavigate(currentSection - 1)
        lastNavigationRef.current = now
        startYRef.current = e.clientY
      } else if (clampedDelta > 50 && currentSection < totalSections - 1) {
        // Pull down = go to next section
        onNavigate(currentSection + 1)
        lastNavigationRef.current = now
        startYRef.current = e.clientY
      }
    }
  }, [isDragging, currentSection, totalSections, onNavigate])

  const handlePointerUp = useCallback(() => {
    setIsDragging(false)
    setDragY(0)
  }, [])

  const canGoUp = currentSection > 0
  const canGoDown = currentSection < totalSections - 1

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 1.5, duration: 0.6 }}
      className="fixed right-4 md:right-8 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center"
    >
      {/* Instruction hint */}
      <AnimatePresence>
        {showHint && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="absolute right-full mr-4 top-1/2 -translate-y-1/2 whitespace-nowrap glass px-3 py-2 rounded-lg text-xs text-muted-foreground"
          >
            <span className="text-primary">Drag</span> up/down to navigate
          </motion.div>
        )}
      </AnimatePresence>

      {/* Up indicator */}
      <motion.div
        animate={{ 
          opacity: dragY < -20 ? 1 : canGoUp ? 0.5 : 0.2,
          scale: dragY < -30 ? 1.2 : 1,
          y: dragY < -20 ? -5 : 0
        }}
        className="mb-2"
      >
        <ChevronUp className={`w-6 h-6 ${canGoUp ? 'text-primary' : 'text-muted-foreground/30'}`} />
      </motion.div>

      {/* PS Controller Joystick */}
      <motion.div
        className="relative w-20 h-32 md:w-24 md:h-40"
        style={{ touchAction: 'none' }}
      >
        {/* Base/Track */}
        <div className="absolute inset-x-0 top-4 bottom-4 mx-auto w-2 rounded-full bg-muted/30" />
        
        {/* Section markers */}
        <div className="absolute inset-x-0 top-4 bottom-4 mx-auto flex flex-col justify-between items-center">
          {Array.from({ length: totalSections }).map((_, i) => (
            <motion.div
              key={i}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                currentSection === i 
                  ? 'bg-primary shadow-[0_0_10px_var(--primary)]' 
                  : 'bg-muted-foreground/30'
              }`}
              animate={currentSection === i ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          ))}
        </div>

        {/* Joystick knob */}
        <motion.button
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className={`absolute left-1/2 -translate-x-1/2 w-14 h-14 md:w-16 md:h-16 rounded-full cursor-grab active:cursor-grabbing touch-none ${
            isDragging ? 'z-50' : ''
          }`}
          style={{ 
            top: `calc(${(currentSection / (totalSections - 1)) * 100}% - 28px)`,
          }}
          animate={{
            y: dragY * 0.5,
            scale: isDragging ? 1.1 : 1,
          }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          whileHover={{ scale: 1.05 }}
          data-cursor-hover
        >
          {/* Outer glow */}
          <motion.div
            className="absolute inset-0 rounded-full"
            animate={{
              boxShadow: isDragging 
                ? '0 0 30px rgba(0, 212, 255, 0.6)' 
                : '0 0 15px rgba(0, 212, 255, 0.3)',
            }}
          />
          
          {/* Joystick body */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-b from-muted/80 to-muted/40 glass border border-primary/30" />
          
          {/* Inner circle */}
          <div className="absolute inset-2 rounded-full bg-gradient-to-b from-primary/20 to-transparent" />
          
          {/* Center dot */}
          <motion.div
            className="absolute inset-0 m-auto w-4 h-4 rounded-full bg-primary"
            animate={{
              boxShadow: [
                '0 0 10px rgba(0, 212, 255, 0.5)',
                '0 0 20px rgba(0, 212, 255, 0.8)',
                '0 0 10px rgba(0, 212, 255, 0.5)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />

          {/* Direction arrows when dragging */}
          <AnimatePresence>
            {isDragging && (
              <>
                {dragY < -10 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="absolute -top-6 left-1/2 -translate-x-1/2"
                  >
                    <ChevronUp className="w-5 h-5 text-primary" />
                  </motion.div>
                )}
                {dragY > 10 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="absolute -bottom-6 left-1/2 -translate-x-1/2"
                  >
                    <ChevronDown className="w-5 h-5 text-primary" />
                  </motion.div>
                )}
              </>
            )}
          </AnimatePresence>
        </motion.button>
      </motion.div>

      {/* Down indicator */}
      <motion.div
        animate={{ 
          opacity: dragY > 20 ? 1 : canGoDown ? 0.5 : 0.2,
          scale: dragY > 30 ? 1.2 : 1,
          y: dragY > 20 ? 5 : 0
        }}
        className="mt-2"
      >
        <ChevronDown className={`w-6 h-6 ${canGoDown ? 'text-primary' : 'text-muted-foreground/30'}`} />
      </motion.div>

      {/* Section label */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="mt-4 text-center"
      >
        <div className="text-xs font-mono text-muted-foreground">
          {['INTRO', 'ABOUT', 'PROJECTS', 'SKILLS', 'CONTACT'][currentSection]}
        </div>
        <div className="text-xs text-primary font-bold">
          {currentSection + 1}/{totalSections}
        </div>
      </motion.div>
    </motion.div>
  )
}
