'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Home, User, Briefcase, Code, Mail } from 'lucide-react'

interface NavigationProps {
  currentSection: number
  onNavigate: (section: number) => void
}

const sections = [
  { name: 'Home', icon: Home },
  { name: 'About', icon: User },
  { name: 'Projects', icon: Briefcase },
  { name: 'Skills', icon: Code },
  { name: 'Contact', icon: Mail },
]

export function Navigation({ currentSection, onNavigate }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <>
      {/* Desktop Navigation - Side dots */}
      <nav className="fixed right-6 top-1/2 -translate-y-1/2 z-40 hidden md:flex flex-col gap-4">
        {sections.map((section, index) => (
          <motion.button
            key={section.name}
            onClick={() => onNavigate(index)}
            className="group relative flex items-center justify-end"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            {/* Label */}
            <span className="absolute right-8 px-3 py-1 rounded-full glass text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap text-foreground">
              {section.name}
            </span>
            {/* Dot */}
            <motion.div
              className={`w-3 h-3 rounded-full border-2 transition-all duration-300 ${
                currentSection === index
                  ? 'bg-primary border-primary scale-125'
                  : 'border-muted-foreground hover:border-primary'
              }`}
              animate={{
                boxShadow: currentSection === index 
                  ? '0 0 10px hsl(180 100% 50% / 0.5)' 
                  : '0 0 0px transparent',
              }}
            />
          </motion.button>
        ))}
      </nav>

      {/* Mobile Navigation - Top bar */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-40 md:hidden transition-all duration-300 ${
          isScrolled ? 'glass' : ''
        }`}
      >
        <div className="flex items-center justify-between px-4 py-4">
          <motion.span 
            className="text-lg font-bold glow-text text-primary"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            AYM
          </motion.span>
          
          <motion.button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-full glass"
            whileTap={{ scale: 0.95 }}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-30 md:hidden glass flex items-center justify-center"
          >
            <nav className="flex flex-col gap-6 text-center">
              {sections.map((section, index) => {
                const Icon = section.icon
                return (
                  <motion.button
                    key={section.name}
                    onClick={() => {
                      onNavigate(index)
                      setIsOpen(false)
                    }}
                    className={`flex items-center gap-4 px-8 py-4 text-xl font-medium transition-colors rounded-lg ${
                      currentSection === index
                        ? 'text-primary glow-text'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Icon size={24} />
                    {section.name}
                  </motion.button>
                )
              })}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Section indicator - Desktop */}
      <motion.div
        className="fixed bottom-6 left-6 z-40 hidden md:block"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <div className="glass px-4 py-2 rounded-full">
          <span className="text-sm font-mono text-muted-foreground">
            <span className="text-primary">{String(currentSection + 1).padStart(2, '0')}</span>
            <span className="mx-2">/</span>
            <span>{String(sections.length).padStart(2, '0')}</span>
          </span>
        </div>
      </motion.div>
    </>
  )
}
