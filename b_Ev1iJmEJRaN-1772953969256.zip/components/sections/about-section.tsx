'use client'

import { motion } from 'framer-motion'
import { Calendar, MapPin, Briefcase, Code, Sparkles } from 'lucide-react'

interface AboutSectionProps {
  isActive: boolean
}

const timeline = [
  {
    year: '2022',
    title: 'Started Web Development',
    description: 'Began learning web development and experimenting with coding projects.',
    color: 'primary',
  },
  {
    year: '2023',
    title: 'First Real Projects',
    description: 'Built first real-time chat applications and personal website prototypes.',
    color: 'secondary',
  },
  {
    year: '2024-2026',
    title: 'Professional Growth',
    description: 'Focused on refining front-end skills, implementing interactive features, and professional projects.',
    color: 'accent',
  },
]

// Animated counter component
function AnimatedCounter({ value, label }: { value: string, label: string }) {
  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="glass p-4 rounded-xl text-center group hover:scale-105 transition-transform"
    >
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-3xl md:text-4xl font-bold gradient-text"
      >
        {value}
      </motion.span>
      <p className="text-xs text-muted-foreground mt-1 group-hover:text-primary transition-colors">
        {label}
      </p>
    </motion.div>
  )
}

export function AboutSection({ isActive }: AboutSectionProps) {
  if (!isActive) return null

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="absolute inset-0 flex items-center justify-center px-4 md:px-6 py-20 overflow-y-auto no-scrollbar"
    >
      {/* Animated background pattern */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute w-96 h-96 rounded-full bg-primary/5 blur-3xl"
          animate={{
            x: [0, 50, 0],
            y: [0, -30, 0],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          style={{ left: '10%', top: '20%' }}
        />
        <motion.div
          className="absolute w-96 h-96 rounded-full bg-secondary/5 blur-3xl"
          animate={{
            x: [0, -40, 0],
            y: [0, 40, 0],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          style={{ right: '10%', bottom: '20%' }}
        />
      </div>

      <div className="max-w-5xl w-full relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-8 md:mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: 'spring' }}
            className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-4"
          >
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-mono text-primary tracking-widest">{'// ABOUT ME'}</span>
          </motion.div>
          <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold">
            <span className="gradient-text">Who I Am</span>
          </h3>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-3 gap-3 md:gap-4 mb-8 md:mb-12 max-w-md mx-auto"
        >
          <AnimatedCounter value="4+" label="Years Experience" />
          <AnimatedCounter value="10+" label="Projects Built" />
          <AnimatedCounter value="3" label="Chatbots Created" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-10">
          {/* Bio */}
          <motion.div
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="space-y-4 md:space-y-6"
          >
            <motion.div 
              className="glass p-5 md:p-6 rounded-xl relative overflow-hidden group"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
              />
              <h4 className="text-lg md:text-xl font-semibold text-foreground mb-3 md:mb-4 flex items-center gap-3">
                <motion.span 
                  className="w-8 h-8 rounded-lg glass flex items-center justify-center"
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                >
                  <Code className="w-4 h-4 text-primary" />
                </motion.span>
                About
              </h4>
              <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
                I am a passionate web developer and tech enthusiast focused on creating 
                interactive, user-friendly applications. I enjoy building projects that 
                blend design with functionality and bring ideas to life through code.
              </p>
            </motion.div>

            <motion.div 
              className="glass p-5 md:p-6 rounded-xl relative overflow-hidden group"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-accent/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
              />
              <h4 className="text-lg md:text-xl font-semibold text-foreground mb-3 md:mb-4 flex items-center gap-3">
                <motion.span 
                  className="w-8 h-8 rounded-lg glass flex items-center justify-center"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Sparkles className="w-4 h-4 text-accent" />
                </motion.span>
                Education & Background
              </h4>
              <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
                Self-taught in web development with hands-on experience in front-end 
                and back-end technologies, including real-time applications and 
                database management.
              </p>
            </motion.div>

            {/* Quick Info */}
            <motion.div 
              className="flex flex-wrap gap-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <motion.div 
                className="glass px-4 py-3 rounded-xl flex items-center gap-3 hover:scale-105 transition-transform cursor-default"
                whileHover={{ y: -2 }}
              >
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">Nigeria</span>
              </motion.div>
              <motion.div 
                className="glass px-4 py-3 rounded-xl flex items-center gap-3 hover:scale-105 transition-transform cursor-default"
                whileHover={{ y: -2 }}
              >
                <Briefcase className="w-4 h-4 text-accent" />
                <span className="text-sm text-muted-foreground">Full-Stack Developer</span>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Timeline */}
          <motion.div
            initial={{ x: 30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h4 className="text-lg md:text-xl font-semibold text-foreground mb-4 md:mb-6 flex items-center gap-3">
              <motion.span
                className="w-8 h-8 rounded-lg glass flex items-center justify-center"
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Calendar className="w-4 h-4 text-secondary" />
              </motion.span>
              Career Timeline
            </h4>
            
            <div className="relative">
              {/* Animated timeline line */}
              <motion.div 
                className="absolute left-3 top-0 bottom-0 w-px"
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                style={{ transformOrigin: 'top' }}
              >
                <div className="h-full bg-gradient-to-b from-primary via-secondary to-accent" />
              </motion.div>
              
              {/* Timeline items */}
              <div className="space-y-4 md:space-y-6">
                {timeline.map((item, index) => (
                  <motion.div
                    key={item.year}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 + index * 0.2 }}
                    className="relative pl-10"
                  >
                    {/* Animated dot */}
                    <motion.div 
                      className="absolute left-0 top-1 w-6 h-6 rounded-full glass flex items-center justify-center"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.9 + index * 0.2, type: 'spring' }}
                    >
                      <motion.div 
                        className={`w-2 h-2 rounded-full ${
                          item.color === 'primary' ? 'bg-primary' :
                          item.color === 'secondary' ? 'bg-secondary' : 'bg-accent'
                        }`}
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                      />
                    </motion.div>
                    
                    {/* Content */}
                    <motion.div 
                      className="glass p-4 rounded-xl group hover:scale-[1.02] transition-all duration-200"
                      whileHover={{ x: 5 }}
                    >
                      <motion.span 
                        className={`font-mono text-sm ${
                          item.color === 'primary' ? 'text-primary' :
                          item.color === 'secondary' ? 'text-secondary' : 'text-accent'
                        }`}
                        animate={{ opacity: [0.7, 1, 0.7] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        {item.year}
                      </motion.span>
                      <h5 className="text-foreground font-semibold mt-1 group-hover:text-primary transition-colors">
                        {item.title}
                      </h5>
                      <p className="text-muted-foreground text-sm mt-2">{item.description}</p>
                    </motion.div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  )
}
