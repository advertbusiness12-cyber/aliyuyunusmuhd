'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react'
import Image from 'next/image'

interface IntroSectionProps {
  isActive: boolean
  onScrollDown: () => void
}

// Typewriter effect hook
function useTypewriter(text: string, speed: number = 50, delay: number = 0) {
  const [displayText, setDisplayText] = useState('')
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    setDisplayText('')
    setIsComplete(false)
    
    const timeout = setTimeout(() => {
      let i = 0
      const interval = setInterval(() => {
        if (i < text.length) {
          setDisplayText(text.slice(0, i + 1))
          i++
        } else {
          clearInterval(interval)
          setIsComplete(true)
        }
      }, speed)
      
      return () => clearInterval(interval)
    }, delay)
    
    return () => clearTimeout(timeout)
  }, [text, speed, delay])

  return { displayText, isComplete }
}

export function IntroSection({ isActive, onScrollDown }: IntroSectionProps) {
  const { displayText: greeting, isComplete: greetingComplete } = useTypewriter('< WELCOME TO MY WORLD />', 40, 500)
  
  if (!isActive) return null

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating geometric shapes */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-32 h-32 border border-primary/20 rounded-lg"
            style={{
              left: `${10 + i * 15}%`,
              top: `${20 + (i % 3) * 25}%`,
            }}
            animate={{
              rotate: [0, 360],
              scale: [1, 1.1, 1],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              duration: 10 + i * 2,
              repeat: Infinity,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      {/* Main content */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="max-w-4xl relative z-10"
      >
        {/* Profile Image */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="relative mx-auto mb-6 w-32 h-32 md:w-40 md:h-40"
        >
          {/* Animated border ring */}
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background: 'conic-gradient(from 0deg, var(--primary), var(--secondary), var(--accent), var(--primary))',
              padding: '3px',
            }}
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
          >
            <div className="w-full h-full rounded-full bg-background" />
          </motion.div>
          
          {/* Profile image */}
          <div className="absolute inset-1 rounded-full overflow-hidden">
            <Image
              src="/images/profile.jpg"
              alt="Aliyu Yunus Muhammad"
              fill
              className="object-cover"
              priority
            />
          </div>
          
          {/* Glow effect */}
          <motion.div
            className="absolute inset-0 rounded-full"
            animate={{
              boxShadow: [
                '0 0 20px rgba(0, 212, 255, 0.3)',
                '0 0 40px rgba(0, 212, 255, 0.5)',
                '0 0 20px rgba(0, 212, 255, 0.3)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          
          {/* Online status indicator */}
          <motion.div
            className="absolute bottom-2 right-2 w-4 h-4 bg-green-500 rounded-full border-2 border-background"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>

        {/* Greeting with typewriter effect */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-primary font-mono text-sm md:text-base mb-4 tracking-widest h-6"
        >
          {greeting}
          {!greetingComplete && (
            <motion.span
              animate={{ opacity: [1, 0] }}
              transition={{ duration: 0.5, repeat: Infinity }}
              className="ml-1"
            >
              |
            </motion.span>
          )}
        </motion.p>

        {/* Name with staggered letter animation */}
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.6 }}
          className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight"
        >
          <span className="text-foreground">{"I'm "}</span>
          <span className="inline-block">
            {['A', 'l', 'i', 'y', 'u', ' ', 'Y', 'u', 'n', 'u', 's'].map((letter, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 + i * 0.05 }}
                className="gradient-text inline-block"
                style={{ minWidth: letter === ' ' ? '0.3em' : undefined }}
              >
                {letter}
              </motion.span>
            ))}
          </span>
          <br />
          <motion.span
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.4 }}
            className="text-foreground"
          >
            Muhammad
          </motion.span>
        </motion.h1>

        {/* Role with glitch effect */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.6 }}
          className="mb-8"
        >
          <h2 className="text-xl md:text-2xl lg:text-3xl font-light text-muted-foreground">
            <motion.span 
              className="text-primary glow-text inline-block"
              animate={{ 
                textShadow: [
                  '0 0 10px var(--primary)',
                  '0 0 20px var(--primary)',
                  '0 0 10px var(--primary)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Full-Stack
            </motion.span>
            {' '}Web Developer
          </h2>
        </motion.div>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.8 }}
          className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Creating interactive, user-friendly applications that blend design with functionality.
          Bringing ideas to life through code.
        </motion.p>

        {/* Social Links with hover effects */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2 }}
          className="flex items-center justify-center gap-6 mb-12"
        >
          {[
            { icon: Github, href: 'https://github.com', label: 'GitHub' },
            { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
            { icon: Mail, href: 'mailto:aliyuyunusmuhammad5@gmail.com', label: 'Email' },
          ].map((social, i) => (
            <motion.a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className="relative p-4 rounded-full glass hover:bg-primary/10 transition-all duration-300 group overflow-hidden"
              data-cursor-hover
              whileHover={{ scale: 1.1, rotate: 5 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 2.2 + i * 0.1 }}
            >
              <social.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors relative z-10" />
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                initial={{ x: '-100%' }}
                whileHover={{ x: '100%' }}
                transition={{ duration: 0.5 }}
              />
            </motion.a>
          ))}
        </motion.div>

        {/* CTA Button with enhanced animation */}
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2.5, type: 'spring', stiffness: 200 }}
          onClick={onScrollDown}
          className="relative px-8 py-4 rounded-full glass neon-border font-medium text-primary overflow-hidden group"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          data-cursor-hover
        >
          <span className="relative z-10 flex items-center gap-2">
            Explore My Work
            <motion.span
              animate={{ y: [0, 3, 0] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <ChevronDown className="w-4 h-4" />
            </motion.span>
          </span>
          <motion.div
            className="absolute inset-0 bg-primary/20"
            initial={{ y: '100%' }}
            whileHover={{ y: 0 }}
            transition={{ duration: 0.3 }}
          />
        </motion.button>
      </motion.div>

      {/* Enhanced scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.button
          onClick={onScrollDown}
          className="flex flex-col items-center gap-3 group cursor-pointer"
          whileHover={{ scale: 1.1 }}
          data-cursor-hover
        >
          <span className="text-xs text-muted-foreground tracking-widest group-hover:text-primary transition-colors">
            SCROLL TO EXPLORE
          </span>
          
          {/* Animated mouse icon */}
          <motion.div
            className="relative w-6 h-10 rounded-full border-2 border-primary/50 group-hover:border-primary transition-colors"
          >
            <motion.div
              className="absolute left-1/2 top-2 w-1 h-2 -translate-x-1/2 bg-primary rounded-full"
              animate={{ y: [0, 12, 0], opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </motion.div>
          
          {/* Animated line */}
          <motion.div 
            className="w-px h-12 relative overflow-hidden"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-b from-primary via-primary to-transparent"
              animate={{ y: ['-100%', '100%'] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </motion.div>
          
          {/* Chevrons */}
          <div className="flex flex-col -mt-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{ opacity: [0.2, 1, 0.2], y: [0, 2, 0] }}
                transition={{ 
                  duration: 1, 
                  repeat: Infinity, 
                  delay: i * 0.15 
                }}
              >
                <ChevronDown className="w-4 h-4 text-primary -my-1" />
              </motion.div>
            ))}
          </div>
        </motion.button>
      </motion.div>

      {/* Corner decorations */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 2 }}
        className="absolute top-8 left-8 w-20 h-20 border-l-2 border-t-2 border-primary/30"
      />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 2.1 }}
        className="absolute top-8 right-8 w-20 h-20 border-r-2 border-t-2 border-primary/30"
      />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 2.2 }}
        className="absolute bottom-8 left-8 w-20 h-20 border-l-2 border-b-2 border-primary/30"
      />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 2.3 }}
        className="absolute bottom-8 right-8 w-20 h-20 border-r-2 border-b-2 border-primary/30"
      />
    </motion.section>
  )
}
