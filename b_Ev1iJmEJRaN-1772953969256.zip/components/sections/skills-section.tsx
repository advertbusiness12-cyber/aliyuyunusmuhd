'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Code, Server, Database, Layers, Palette, Terminal, Zap, TrendingUp } from 'lucide-react'

interface SkillsSectionProps {
  isActive: boolean
}

const skills = [
  { name: 'HTML', level: 95, category: 'frontend', icon: Code, color: '#E34F26' },
  { name: 'CSS', level: 90, category: 'frontend', icon: Palette, color: '#1572B6' },
  { name: 'JavaScript', level: 85, category: 'frontend', icon: Terminal, color: '#F7DF1E' },
  { name: 'Python (Flask)', level: 80, category: 'backend', icon: Server, color: '#3776AB' },
  { name: 'Databases', level: 85, category: 'backend', icon: Database, color: '#00758F' },
  { name: 'Full-Stack Projects', level: 90, category: 'fullstack', icon: Layers, color: '#00D4FF' },
]

const categories = [
  { id: 'all', name: 'All Skills', icon: Zap },
  { id: 'frontend', name: 'Frontend', icon: Code },
  { id: 'backend', name: 'Backend', icon: Server },
  { id: 'fullstack', name: 'Full-Stack', icon: Layers },
]

// Animated circular progress
function CircularProgress({ value, color, delay }: { value: number, color: string, delay: number }) {
  const circumference = 2 * Math.PI * 40
  const strokeDashoffset = circumference - (value / 100) * circumference

  return (
    <div className="relative w-24 h-24">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
        {/* Background circle */}
        <circle
          cx="50"
          cy="50"
          r="40"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          className="text-muted/30"
        />
        {/* Progress circle */}
        <motion.circle
          cx="50"
          cy="50"
          r="40"
          fill="none"
          stroke={color}
          strokeWidth="4"
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1.5, delay, ease: 'easeOut' }}
          style={{
            strokeDasharray: circumference,
            filter: `drop-shadow(0 0 6px ${color}80)`,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.span
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.5 }}
          className="text-lg font-bold text-foreground"
        >
          {value}%
        </motion.span>
      </div>
    </div>
  )
}

export function SkillsSection({ isActive }: SkillsSectionProps) {
  const [activeCategory, setActiveCategory] = useState('all')
  const [animateSkills, setAnimateSkills] = useState(false)
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null)

  useEffect(() => {
    if (isActive) {
      const timer = setTimeout(() => setAnimateSkills(true), 500)
      return () => clearTimeout(timer)
    } else {
      setAnimateSkills(false)
    }
  }, [isActive])

  const filteredSkills = activeCategory === 'all' 
    ? skills 
    : skills.filter(skill => skill.category === activeCategory)

  if (!isActive) return null

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="absolute inset-0 flex items-center justify-center px-4 md:px-6 py-20 overflow-y-auto no-scrollbar"
    >
      {/* Animated background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {skills.map((skill, i) => (
          <motion.div
            key={skill.name}
            className="absolute w-2 h-2 rounded-full"
            style={{ 
              backgroundColor: skill.color,
              left: `${15 + i * 15}%`,
              top: `${20 + (i % 3) * 30}%`,
              filter: `blur(1px)`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.6, 0.3],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 3 + i,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </div>

      <div className="max-w-5xl w-full relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-8 md:mb-12"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: 'spring' }}
            className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-4"
          >
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-sm font-mono text-primary tracking-widest">{'// EXPERTISE'}</span>
          </motion.div>
          <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold gradient-text">
            Skills & Technologies
          </h3>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto text-sm md:text-base">
            Constantly learning and improving to deliver the best solutions
          </p>
        </motion.div>

        {/* Category filters */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8 md:mb-10"
        >
          {categories.map((category, index) => {
            const Icon = category.icon
            return (
              <motion.button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-3 md:px-4 py-2 rounded-full text-xs md:text-sm font-medium transition-all flex items-center gap-2 ${
                  activeCategory === category.id
                    ? 'bg-primary text-primary-foreground shadow-[0_0_15px_var(--primary)]'
                    : 'glass text-muted-foreground hover:text-foreground'
                }`}
                data-cursor-hover
              >
                <Icon className="w-3 h-3 md:w-4 md:h-4" />
                <span className="hidden sm:inline">{category.name}</span>
              </motion.button>
            )
          })}
        </motion.div>

        {/* Skills grid */}
        <AnimatePresence mode="wait">
          <motion.div 
            key={activeCategory}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6"
          >
            {filteredSkills.map((skill, index) => {
              const Icon = skill.icon
              const isHovered = hoveredSkill === skill.name
              
              return (
                <motion.div
                  key={skill.name}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 + index * 0.1 }}
                  onMouseEnter={() => setHoveredSkill(skill.name)}
                  onMouseLeave={() => setHoveredSkill(null)}
                  className="glass p-4 md:p-5 rounded-xl group relative overflow-hidden"
                  whileHover={{ scale: 1.03, y: -5 }}
                  data-cursor-hover
                >
                  {/* Glowing background on hover */}
                  <motion.div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      background: `radial-gradient(circle at center, ${skill.color}15 0%, transparent 70%)`,
                    }}
                  />

                  <div className="flex items-center gap-4 relative z-10">
                    {/* Circular progress */}
                    <CircularProgress 
                      value={animateSkills ? skill.level : 0} 
                      color={skill.color}
                      delay={0.4 + index * 0.1}
                    />

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <motion.div 
                          className="w-8 h-8 rounded-lg glass flex items-center justify-center"
                          style={{ color: skill.color }}
                          animate={isHovered ? { rotate: [0, 10, -10, 0] } : {}}
                          transition={{ duration: 0.5 }}
                        >
                          <Icon className="w-4 h-4" />
                        </motion.div>
                        <span className="font-semibold text-foreground text-sm md:text-base">
                          {skill.name}
                        </span>
                      </div>

                      {/* Mini progress bar */}
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: animateSkills ? `${skill.level}%` : 0 }}
                          transition={{ duration: 1, delay: 0.6 + index * 0.1, ease: 'easeOut' }}
                          className="h-full rounded-full"
                          style={{
                            backgroundColor: skill.color,
                            boxShadow: `0 0 10px ${skill.color}80`,
                          }}
                        />
                      </div>

                      <span className="text-xs text-muted-foreground mt-1 capitalize block">
                        {skill.category}
                      </span>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        </AnimatePresence>

        {/* Bottom stats */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-8 md:mt-12 grid grid-cols-3 gap-3 md:gap-4"
        >
          {[
            { value: '4+', label: 'Years Learning', color: 'primary' },
            { value: '10+', label: 'Projects Built', color: 'secondary' },
            { value: '6+', label: 'Technologies', color: 'accent' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              className="glass p-3 md:p-4 rounded-xl text-center group hover:scale-105 transition-transform"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.9 + i * 0.1 }}
              whileHover={{ y: -3 }}
            >
              <motion.div 
                className={`text-2xl md:text-3xl font-bold text-${stat.color} mb-1`}
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
              >
                {stat.value}
              </motion.div>
              <div className="text-xs text-muted-foreground group-hover:text-foreground transition-colors">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </motion.section>
  )
}
