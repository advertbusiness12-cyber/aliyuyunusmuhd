'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ExternalLink, Code, Database, Bot, MessageSquare, GraduationCap, Briefcase, Maximize2, Minimize2 } from 'lucide-react'

interface ProjectsSectionProps {
  isActive: boolean
}

const projects = [
  {
    id: 1,
    title: 'Business Assistant Chatbot',
    description: 'Real-time chatbot helping businesses manage queries efficiently. Features intelligent response generation and seamless conversation flow.',
    longDescription: 'A comprehensive chatbot solution designed to help businesses automate customer interactions. Built with real-time messaging capabilities, intelligent query handling, and a robust backend for managing conversation history and analytics.',
    icon: Briefcase,
    tech: ['HTML', 'CSS', 'JavaScript', 'Python', 'Flask', 'SQLite'],
    color: 'primary',
    features: ['Real-time messaging', 'Order management', 'Payment integration', 'Admin dashboard'],
    demoType: 'business-assistant',
  },
  {
    id: 2,
    title: 'LiveChat Bot',
    description: 'Interactive live chat application for real-time communication with modern UI and instant message delivery.',
    longDescription: 'A feature-rich live chat application enabling real-time communication between users and support teams. Includes typing indicators, read receipts, and message threading for organized conversations.',
    icon: MessageSquare,
    tech: ['HTML', 'CSS', 'JavaScript', 'Python', 'Flask', 'Socket.IO'],
    color: 'secondary',
    features: ['Instant messaging', 'File sharing', 'User search', 'Message history'],
    demoType: 'livechat',
  },
  {
    id: 3,
    title: 'University FAQ Chatbot',
    description: 'Chatbot designed to answer student questions instantly, providing quick access to university information.',
    longDescription: 'An intelligent FAQ system built specifically for university environments. Students can get instant answers to common questions about admissions, courses, schedules, and campus facilities.',
    icon: GraduationCap,
    tech: ['HTML', 'CSS', 'JavaScript', 'Fuse.js', 'LocalStorage'],
    color: 'accent',
    features: ['Smart search', 'Dark mode', 'Fee calculator', 'Course info'],
    demoType: 'university-faq',
  },
]

// Demo components embedded directly
function BusinessAssistantDemo() {
  return (
    <div className="w-full h-full bg-[#e5ddd5] overflow-auto">
      <div className="bg-[#075e54] text-white p-3 fixed top-0 left-0 right-0 z-10 flex justify-between items-center">
        <div>
          <strong className="text-lg">Zaifat Treats</strong>
          <br />
          <small className="text-green-200">Online</small>
        </div>
        <span className="bg-white/20 px-2 py-1 rounded text-xs">Admin</span>
      </div>
      <div className="pt-16 pb-16 p-4">
        <div className="bg-white p-3 rounded-lg shadow-sm mb-2 max-w-[75%]">
          Welcome to Zaifat Treats! What is your name?
        </div>
        <div className="bg-[#dcf8c6] p-3 rounded-lg shadow-sm mb-2 max-w-[75%] ml-auto">
          Demo User
        </div>
        <div className="bg-white p-3 rounded-lg shadow-sm mb-2 max-w-[75%]">
          Hello <b>Demo User</b>! Browse our Yaji and Tea:
        </div>
        <div className="flex gap-3 overflow-x-auto py-2">
          {['Yaji Mix', 'Special Tea', 'Suya Spice'].map((item, i) => (
            <div key={i} className="bg-white p-3 rounded-lg min-w-[120px] text-center shadow-sm">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-lg mx-auto mb-2" />
              <h5 className="font-medium text-sm">{item}</h5>
              <p className="text-xs text-gray-500">N{(i + 1) * 500}</p>
              <button className="bg-[#25d366] text-white w-full py-1 rounded mt-1 text-xs">Add</button>
            </div>
          ))}
        </div>
        <div className="bg-white p-3 rounded-lg shadow-sm max-w-[75%]">
          {"Type 'DONE' when ready to pay."}
        </div>
      </div>
      <div className="fixed bottom-0 left-0 right-0 bg-[#f0f0f0] p-2 flex gap-2">
        <input 
          type="text" 
          placeholder="Type 'DONE' or a message..." 
          className="flex-1 border-none rounded-full px-4 py-2 text-sm"
        />
        <button className="bg-[#34b7f1] text-white w-10 h-10 rounded-full flex items-center justify-center">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
          </svg>
        </button>
      </div>
    </div>
  )
}

function LiveChatDemo() {
  return (
    <div className="w-full h-full bg-[#dadbd3] flex">
      {/* Sidebar */}
      <div className="w-1/3 bg-white border-r flex flex-col">
        <div className="bg-[#075e54] text-white p-4">
          <strong>Chat</strong>
        </div>
        <div className="p-2 border-b">
          <input 
            type="text" 
            placeholder="Search user..." 
            className="w-full px-3 py-2 rounded border text-sm"
          />
        </div>
        <div className="flex-1 overflow-auto">
          {['John Doe', 'Jane Smith', 'Alex Johnson'].map((name, i) => (
            <div key={i} className={`p-3 border-b cursor-pointer hover:bg-gray-50 ${i === 0 ? 'bg-gray-100' : ''}`}>
              <span className="font-medium text-sm">{name}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Chat area */}
      <div className="flex-1 flex flex-col bg-[#e5ddd5]">
        <div className="bg-[#075e54] text-white p-4 flex items-center gap-3">
          <strong>John Doe</strong>
        </div>
        <div className="flex-1 p-4 overflow-auto">
          <div className="bg-white p-2 px-3 rounded-lg shadow-sm mb-2 max-w-[70%] text-sm">
            Hey, how are you?
            <div className="text-[10px] text-gray-400 text-right">10:30 AM</div>
          </div>
          <div className="bg-[#dcf8c6] p-2 px-3 rounded-lg shadow-sm mb-2 max-w-[70%] ml-auto text-sm">
            {"I'm doing great, thanks!"}
            <div className="text-[10px] text-gray-400 text-right">10:31 AM</div>
          </div>
          <div className="bg-white p-2 px-3 rounded-lg shadow-sm max-w-[70%] text-sm">
            Want to grab coffee?
            <div className="text-[10px] text-gray-400 text-right">10:32 AM</div>
          </div>
        </div>
        <div className="bg-[#f0f0f0] p-2 flex gap-2">
          <button className="text-xl">📎</button>
          <input 
            type="text" 
            placeholder="Type a message..." 
            className="flex-1 border-none rounded-full px-4 py-2 text-sm"
          />
          <button className="text-xl">➤</button>
        </div>
      </div>
    </div>
  )
}

function UniversityFAQDemo() {
  return (
    <div className="w-full h-full bg-[#f0f2f5] flex flex-col">
      <div className="bg-gradient-to-r from-[#4b6cf7] to-[#5fa3f7] text-white p-4 flex justify-between items-center">
        <h3 className="font-semibold">MAAUN University FAQ Chatbot</h3>
        <button className="bg-white/20 px-3 py-1 rounded text-sm">Dark Mode</button>
      </div>
      
      <div className="flex-1 p-4 overflow-auto bg-white mx-4 my-2 rounded-xl shadow-lg">
        <div className="bg-[#e0e0e0] p-3 rounded-2xl max-w-[80%] mb-3 text-sm shadow">
          Hello! Ask about school fees, courses, or admission.
        </div>
        <div className="bg-[#4b6cf7] text-white p-3 rounded-2xl max-w-[80%] ml-auto mb-3 text-sm shadow">
          What courses are offered?
        </div>
        <div className="bg-[#e0e0e0] p-3 rounded-2xl max-w-[80%] text-sm shadow">
          MAAUN offers courses in: Computing (Cyber Security, Computer Science, Software Engineering), 
          Health Sciences (Nursing, Medical Lab), Law, Medicine & Surgery, and more!
        </div>
      </div>
      
      <div className="p-4 border-t bg-[#f7f7f7]">
        <div className="flex flex-wrap gap-2 mb-3">
          {['School fees', 'Apply for admission'].map((q, i) => (
            <button key={i} className="bg-[#4b6cf7] text-white px-3 py-2 rounded-full text-xs">
              {q}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-3">
        <div className="flex bg-white rounded-full shadow-lg overflow-hidden">
          <input 
            type="text" 
            placeholder="Type question..." 
            className="flex-1 px-4 py-3 border-none text-sm"
          />
          <button className="bg-[#4b6cf7] text-white px-5">Send</button>
        </div>
      </div>
    </div>
  )
}

export function ProjectsSection({ isActive }: ProjectsSectionProps) {
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)

  if (!isActive) return null

  const renderDemo = (demoType: string) => {
    switch (demoType) {
      case 'business-assistant':
        return <BusinessAssistantDemo />
      case 'livechat':
        return <LiveChatDemo />
      case 'university-faq':
        return <UniversityFAQDemo />
      default:
        return null
    }
  }

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="absolute inset-0 flex items-center justify-center px-4 md:px-6 py-20 overflow-y-auto no-scrollbar"
    >
      <div className="max-w-6xl w-full">
        {/* Section header */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-12"
        >
          <h2 className="text-sm font-mono text-primary mb-2 tracking-widest">{'// MY WORK'}</h2>
          <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold gradient-text">Featured Projects</h3>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Click on any project to view a live demo and explore its features
          </p>
        </motion.div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => {
            const Icon = project.icon
            const colorClass = project.color === 'primary' 
              ? 'text-primary' 
              : project.color === 'secondary' 
                ? 'text-secondary' 
                : 'text-accent'
            const borderClass = project.color === 'primary'
              ? 'hover:border-primary/50'
              : project.color === 'secondary'
                ? 'hover:border-secondary/50'
                : 'hover:border-accent/50'

            return (
              <motion.div
                key={project.id}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.15 }}
                onClick={() => setSelectedProject(project)}
                className={`glass p-6 rounded-xl cursor-pointer transition-all duration-300 border border-transparent ${borderClass} hover:scale-[1.02] group`}
                whileHover={{ y: -5 }}
                whileTap={{ scale: 0.98 }}
                data-cursor-hover
              >
                {/* Icon */}
                <div className={`w-12 h-12 rounded-xl glass flex items-center justify-center mb-4 ${colorClass}`}>
                  <Icon className="w-6 h-6" />
                </div>

                {/* Title */}
                <h4 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h4>

                {/* Description */}
                <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                  {project.description}
                </p>

                {/* Tech stack */}
                <div className="flex flex-wrap gap-2">
                  {project.tech.slice(0, 3).map((tech) => (
                    <span
                      key={tech}
                      className="px-2 py-1 text-xs rounded-full bg-muted/50 text-muted-foreground"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.tech.length > 3 && (
                    <span className="px-2 py-1 text-xs rounded-full bg-muted/50 text-muted-foreground">
                      +{project.tech.length - 3}
                    </span>
                  )}
                </div>

                {/* View demo badge */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute top-4 right-4 px-2 py-1 rounded-full bg-primary/20 text-primary text-xs font-medium"
                >
                  View Demo
                </motion.div>
              </motion.div>
            )
          })}
        </div>

        {/* Project detail modal with demo */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
              onClick={() => {
                setSelectedProject(null)
                setIsFullscreen(false)
              }}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className={`glass w-full max-h-[90vh] overflow-hidden rounded-2xl ${
                  isFullscreen ? 'max-w-6xl' : 'max-w-4xl'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-muted/20">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg glass flex items-center justify-center ${
                      selectedProject.color === 'primary' 
                        ? 'text-primary' 
                        : selectedProject.color === 'secondary' 
                          ? 'text-secondary' 
                          : 'text-accent'
                    }`}>
                      <selectedProject.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{selectedProject.title}</h4>
                      <p className="text-xs text-muted-foreground">Live Demo</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsFullscreen(!isFullscreen)}
                      className="p-2 rounded-lg glass hover:bg-muted/50 transition-colors"
                      data-cursor-hover
                    >
                      {isFullscreen ? (
                        <Minimize2 className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <Maximize2 className="w-4 h-4 text-muted-foreground" />
                      )}
                    </button>
                    <button
                      onClick={() => {
                        setSelectedProject(null)
                        setIsFullscreen(false)
                      }}
                      className="p-2 rounded-lg glass hover:bg-muted/50 transition-colors"
                      data-cursor-hover
                    >
                      <X className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </div>
                </div>

                {/* Demo area */}
                <div className={`${isFullscreen ? 'h-[70vh]' : 'h-[50vh]'} overflow-hidden`}>
                  {renderDemo(selectedProject.demoType)}
                </div>

                {/* Footer with info */}
                <div className="p-4 border-t border-muted/20">
                  <div className="flex flex-wrap gap-4 justify-between items-start">
                    <div className="flex-1 min-w-[200px]">
                      <h5 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                        <Code className="w-4 h-4 text-primary" />
                        Technologies
                      </h5>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.tech.map((tech) => (
                          <span
                            key={tech}
                            className="px-2 py-1 text-xs rounded-full glass text-foreground"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex-1 min-w-[200px]">
                      <h5 className="text-sm font-semibold text-foreground mb-2 flex items-center gap-2">
                        <Database className="w-4 h-4 text-secondary" />
                        Key Features
                      </h5>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.features.map((feature) => (
                          <span key={feature} className="text-xs text-muted-foreground flex items-center gap-1">
                            <span className="w-1 h-1 rounded-full bg-primary" />
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.section>
  )
}
