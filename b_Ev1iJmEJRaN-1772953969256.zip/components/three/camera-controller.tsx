'use client'

import { useRef, useEffect } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import gsap from 'gsap'

interface CameraControllerProps {
  scrollProgress: number
  currentSection: number
}

// Camera path waypoints for each section
const cameraWaypoints = [
  // Intro - Looking at city from distance
  { position: new THREE.Vector3(0, 8, 15), lookAt: new THREE.Vector3(0, 5, -10) },
  // About - Moving into the city
  { position: new THREE.Vector3(0, 6, -10), lookAt: new THREE.Vector3(0, 4, -30) },
  // Projects - Through the city streets
  { position: new THREE.Vector3(2, 5, -40), lookAt: new THREE.Vector3(-2, 5, -60) },
  // Skills - Higher viewpoint
  { position: new THREE.Vector3(-2, 8, -80), lookAt: new THREE.Vector3(2, 4, -100) },
  // Contact - End of journey
  { position: new THREE.Vector3(0, 5, -120), lookAt: new THREE.Vector3(0, 5, -150) },
]

export function CameraController({ scrollProgress, currentSection }: CameraControllerProps) {
  const { camera } = useThree()
  const targetPosition = useRef(new THREE.Vector3())
  const targetLookAt = useRef(new THREE.Vector3())
  const currentLookAt = useRef(new THREE.Vector3(0, 5, -10))
  
  useEffect(() => {
    // Calculate which section we're in based on scroll progress
    const totalSections = cameraWaypoints.length - 1
    const exactSection = scrollProgress * totalSections
    const sectionIndex = Math.floor(exactSection)
    const sectionProgress = exactSection - sectionIndex
    
    // Clamp to valid indices
    const fromIndex = Math.min(sectionIndex, totalSections)
    const toIndex = Math.min(sectionIndex + 1, totalSections)
    
    const from = cameraWaypoints[fromIndex]
    const to = cameraWaypoints[toIndex]
    
    // Smooth easing for the transition
    const eased = gsap.parseEase('power2.inOut')(sectionProgress)
    
    // Interpolate position
    targetPosition.current.lerpVectors(from.position, to.position, eased)
    targetLookAt.current.lerpVectors(from.lookAt, to.lookAt, eased)
  }, [scrollProgress])
  
  useFrame(() => {
    // Smooth camera movement
    camera.position.lerp(targetPosition.current, 0.05)
    currentLookAt.current.lerp(targetLookAt.current, 0.05)
    camera.lookAt(currentLookAt.current)
    
    // Add subtle camera shake for immersion
    const time = Date.now() * 0.001
    camera.position.x += Math.sin(time * 0.5) * 0.02
    camera.position.y += Math.cos(time * 0.3) * 0.01
  })
  
  return null
}
