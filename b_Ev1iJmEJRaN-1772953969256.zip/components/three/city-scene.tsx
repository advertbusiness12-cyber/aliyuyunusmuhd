'use client'

import { useRef, useMemo, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, Float } from '@react-three/drei'
import * as THREE from 'three'

// Procedural Building Component
function Building({ position, scale, color }: { position: [number, number, number], scale: [number, number, number], color: string }) {
  const meshRef = useRef<THREE.Mesh>(null)
  
  // Random window pattern
  const windowTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 64
    canvas.height = 128
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#0a0a0a'
    ctx.fillRect(0, 0, 64, 128)
    
    // Draw windows
    for (let y = 0; y < 16; y++) {
      for (let x = 0; x < 4; x++) {
        if (Math.random() > 0.3) {
          const brightness = Math.random() * 0.5 + 0.2
          ctx.fillStyle = `rgba(0, 212, 255, ${brightness})`
          ctx.fillRect(x * 16 + 2, y * 8 + 1, 12, 6)
        }
      }
    }
    
    const texture = new THREE.CanvasTexture(canvas)
    texture.wrapS = THREE.RepeatWrapping
    texture.wrapT = THREE.RepeatWrapping
    texture.repeat.set(1, scale[1] / 2)
    return texture
  }, [scale])
  
  return (
    <mesh ref={meshRef} position={position} castShadow receiveShadow>
      <boxGeometry args={scale} />
      <meshStandardMaterial 
        color={color} 
        map={windowTexture}
        emissive="#00d4ff"
        emissiveIntensity={0.05}
        roughness={0.8}
        metalness={0.2}
      />
    </mesh>
  )
}

// Interactive 3D Hologram for Projects
interface HologramProps {
  position: [number, number, number]
  label: string
  color: string
  onClick?: () => void
  sectionIndex: number
}

function InteractiveHologram({ position, label, color, onClick, sectionIndex }: HologramProps) {
  const [hovered, setHovered] = useState(false)
  const groupRef = useRef<THREE.Group>(null)
  const ringRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.5
    }
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 2
    }
  })

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
      <group 
        ref={groupRef} 
        position={position}
        onClick={onClick}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        {/* Central cube */}
        <mesh>
          <boxGeometry args={[1.5, 1.5, 1.5]} />
          <meshStandardMaterial 
            color={color}
            emissive={color}
            emissiveIntensity={hovered ? 1.5 : 0.8}
            transparent
            opacity={0.7}
            wireframe={hovered}
          />
        </mesh>
        
        {/* Rotating ring */}
        <mesh ref={ringRef} rotation={[Math.PI / 4, 0, 0]}>
          <torusGeometry args={[2, 0.05, 8, 32]} />
          <meshStandardMaterial 
            color={color}
            emissive={color}
            emissiveIntensity={1.5}
            transparent
            opacity={0.8}
          />
        </mesh>
        
        {/* Outer ring */}
        <mesh rotation={[-Math.PI / 4, 0, Math.PI / 4]}>
          <torusGeometry args={[2.5, 0.03, 8, 32]} />
          <meshStandardMaterial 
            color={color}
            emissive={color}
            emissiveIntensity={1}
            transparent
            opacity={0.5}
          />
        </mesh>

        {/* Light source */}
        <pointLight color={color} intensity={hovered ? 3 : 1.5} distance={15} />
        
        {/* Label */}
        <Html center distanceFactor={15} style={{ pointerEvents: 'none' }}>
          <div className={`px-4 py-2 rounded-lg glass text-center whitespace-nowrap transition-all duration-300 ${hovered ? 'scale-110' : ''}`}>
            <span className="text-sm font-mono" style={{ color }}>{label}</span>
            {hovered && (
              <p className="text-xs text-white/60 mt-1">Click to explore</p>
            )}
          </div>
        </Html>
      </group>
    </Float>
  )
}

// Flying Drone/Satellite
function FlyingDrone({ startPosition, color }: { startPosition: [number, number, number], color: string }) {
  const droneRef = useRef<THREE.Group>(null)
  const lightRef = useRef<THREE.PointLight>(null)
  const offset = useMemo(() => Math.random() * Math.PI * 2, [])
  
  useFrame((state) => {
    if (droneRef.current) {
      const time = state.clock.elapsedTime + offset
      droneRef.current.position.x = startPosition[0] + Math.sin(time * 0.5) * 15
      droneRef.current.position.y = startPosition[1] + Math.sin(time * 0.8) * 3
      droneRef.current.position.z = startPosition[2] + Math.cos(time * 0.3) * 20
      droneRef.current.rotation.y = time * 2
    }
    if (lightRef.current) {
      lightRef.current.intensity = 1 + Math.sin(state.clock.elapsedTime * 5) * 0.5
    }
  })
  
  return (
    <group ref={droneRef} position={startPosition}>
      {/* Drone body */}
      <mesh>
        <octahedronGeometry args={[0.3]} />
        <meshStandardMaterial 
          color={color}
          emissive={color}
          emissiveIntensity={1.5}
        />
      </mesh>
      {/* Trailing light */}
      <pointLight ref={lightRef} color={color} intensity={1.5} distance={10} />
      {/* Trail effect */}
      <mesh position={[0, 0, 0.5]}>
        <coneGeometry args={[0.1, 0.8, 8]} />
        <meshStandardMaterial 
          color={color}
          emissive={color}
          emissiveIntensity={2}
          transparent
          opacity={0.5}
        />
      </mesh>
    </group>
  )
}

// Animated Neon Sign Component
function NeonSign({ position, text, color }: { position: [number, number, number], text: string, color: string }) {
  const lightRef = useRef<THREE.PointLight>(null)
  const meshRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (lightRef.current) {
      // Flickering effect
      const flicker = Math.sin(state.clock.elapsedTime * 10) * 0.2 + 
                     Math.sin(state.clock.elapsedTime * 23) * 0.1
      lightRef.current.intensity = 2 + flicker
    }
    if (meshRef.current) {
      meshRef.current.material.emissiveIntensity = 1.5 + Math.sin(state.clock.elapsedTime * 3) * 0.5
    }
  })
  
  return (
    <group position={position}>
      <pointLight ref={lightRef} color={color} intensity={2} distance={15} />
      <mesh ref={meshRef}>
        <boxGeometry args={[2, 0.5, 0.1]} />
        <meshStandardMaterial 
          color={color} 
          emissive={color} 
          emissiveIntensity={2}
        />
      </mesh>
    </group>
  )
}

// Road Component
function Road({ position, rotation, length }: { position: [number, number, number], rotation?: [number, number, number], length: number }) {
  const lineRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (lineRef.current) {
      // Animated road line glow
      const material = lineRef.current.material as THREE.MeshStandardMaterial
      material.emissiveIntensity = 0.3 + Math.sin(state.clock.elapsedTime * 2) * 0.15
    }
  })
  
  return (
    <group position={position} rotation={rotation || [0, 0, 0]}>
      {/* Main road */}
      <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[8, length]} />
        <meshStandardMaterial color="#1a1a1a" roughness={0.9} />
      </mesh>
      {/* Animated road line */}
      <mesh ref={lineRef} position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.2, length]} />
        <meshStandardMaterial color="#ffff00" emissive="#ffff00" emissiveIntensity={0.3} />
      </mesh>
    </group>
  )
}

// Street Light Component with animated light
function StreetLight({ position }: { position: [number, number, number] }) {
  const lightRef = useRef<THREE.PointLight>(null)
  
  useFrame((state) => {
    if (lightRef.current) {
      lightRef.current.intensity = 1 + Math.sin(state.clock.elapsedTime * 0.5 + position[2]) * 0.3
    }
  })
  
  return (
    <group position={position}>
      {/* Pole */}
      <mesh position={[0, 3, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 6, 8]} />
        <meshStandardMaterial color="#333333" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Light fixture */}
      <mesh position={[0, 6, 0]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial 
          color="#00d4ff" 
          emissive="#00d4ff" 
          emissiveIntensity={2}
        />
      </mesh>
      <pointLight ref={lightRef} position={[0, 5.5, 0]} color="#00d4ff" intensity={1} distance={20} castShadow />
    </group>
  )
}

// Floating Particles with enhanced animation
function Particles({ count = 200 }) {
  const meshRef = useRef<THREE.Points>(null)
  
  const particles = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const colors = new Float32Array(count * 3)
    const color = new THREE.Color()
    
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 100
      positions[i * 3 + 1] = Math.random() * 50
      positions[i * 3 + 2] = (Math.random() - 0.5) * 200
      
      // Random colors between cyan, magenta, and yellow
      const colorChoice = Math.random()
      if (colorChoice < 0.33) {
        color.setHSL(0.5, 1, 0.5) // Cyan
      } else if (colorChoice < 0.66) {
        color.setHSL(0.85, 1, 0.5) // Magenta
      } else {
        color.setHSL(0.15, 1, 0.5) // Yellow/Orange
      }
      colors[i * 3] = color.r
      colors[i * 3 + 1] = color.g
      colors[i * 3 + 2] = color.b
    }
    return { positions, colors }
  }, [count])
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.02
      const positions = meshRef.current.geometry.attributes.position.array as Float32Array
      for (let i = 0; i < count; i++) {
        // Wave-like motion
        positions[i * 3 + 1] += Math.sin(state.clock.elapsedTime * 0.5 + i * 0.1) * 0.01
        // Slow drift
        positions[i * 3] += Math.sin(state.clock.elapsedTime * 0.2 + i) * 0.005
      }
      meshRef.current.geometry.attributes.position.needsUpdate = true
    }
  })
  
  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={particles.positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={particles.colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial 
        size={0.2} 
        vertexColors
        transparent 
        opacity={0.7}
        sizeAttenuation
      />
    </points>
  )
}

// Data Stream Effect
function DataStream({ startZ, color }: { startZ: number, color: string }) {
  const meshRef = useRef<THREE.Mesh>(null)
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = 30 + Math.sin(state.clock.elapsedTime * 2) * 5
      const material = meshRef.current.material as THREE.MeshStandardMaterial
      material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 3) * 0.2
    }
  })
  
  return (
    <mesh ref={meshRef} position={[0, 30, startZ]}>
      <cylinderGeometry args={[0.02, 0.02, 60, 8]} />
      <meshStandardMaterial 
        color={color}
        emissive={color}
        emissiveIntensity={2}
        transparent
        opacity={0.5}
      />
    </mesh>
  )
}

// Main City Scene
export function CityScene({ onSectionClick }: { onSectionClick?: (section: number) => void }) {
  // Generate buildings procedurally
  const buildings = useMemo(() => {
    const result: Array<{ position: [number, number, number], scale: [number, number, number], color: string }> = []
    const colors = ['#1a1a2e', '#16213e', '#0f3460', '#1a1a1a', '#2d2d44']
    
    // Left side buildings (along the path)
    for (let z = 0; z > -180; z -= 15) {
      const height = Math.random() * 15 + 8
      result.push({
        position: [-15 + Math.random() * 5, height / 2, z + Math.random() * 5],
        scale: [6 + Math.random() * 4, height, 6 + Math.random() * 4],
        color: colors[Math.floor(Math.random() * colors.length)]
      })
    }
    
    // Right side buildings
    for (let z = 0; z > -180; z -= 15) {
      const height = Math.random() * 15 + 8
      result.push({
        position: [15 + Math.random() * 5, height / 2, z + Math.random() * 5],
        scale: [6 + Math.random() * 4, height, 6 + Math.random() * 4],
        color: colors[Math.floor(Math.random() * colors.length)]
      })
    }
    
    // Additional background buildings
    for (let i = 0; i < 30; i++) {
      const height = Math.random() * 20 + 5
      const side = Math.random() > 0.5 ? 1 : -1
      result.push({
        position: [side * (25 + Math.random() * 20), height / 2, -Math.random() * 200],
        scale: [5 + Math.random() * 8, height, 5 + Math.random() * 8],
        color: colors[Math.floor(Math.random() * colors.length)]
      })
    }
    
    return result
  }, [])
  
  // Generate street lights
  const streetLights = useMemo(() => {
    const lights: Array<[number, number, number]> = []
    for (let z = 0; z > -180; z -= 20) {
      lights.push([-6, 0, z])
      lights.push([6, 0, z])
    }
    return lights
  }, [])
  
  // Generate neon signs
  const neonSigns = useMemo(() => [
    { position: [-12, 8, -20] as [number, number, number], text: 'WELCOME', color: '#ff00ff' },
    { position: [12, 10, -50] as [number, number, number], text: 'PROJECTS', color: '#00ffff' },
    { position: [-12, 12, -80] as [number, number, number], text: 'SKILLS', color: '#ff6600' },
    { position: [12, 9, -120] as [number, number, number], text: 'CONTACT', color: '#00ff66' },
  ], [])

  // Interactive holograms for each section
  const holograms = useMemo(() => [
    { position: [0, 12, -25] as [number, number, number], label: '// ABOUT ME', color: '#00ffff', sectionIndex: 1 },
    { position: [0, 12, -55] as [number, number, number], label: '// PROJECTS', color: '#ff00ff', sectionIndex: 2 },
    { position: [0, 12, -90] as [number, number, number], label: '// SKILLS', color: '#ff6600', sectionIndex: 3 },
    { position: [0, 12, -130] as [number, number, number], label: '// CONTACT', color: '#00ff66', sectionIndex: 4 },
  ], [])
  
  return (
    <group>
      {/* Ground plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, -90]} receiveShadow>
        <planeGeometry args={[200, 250]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.95} />
      </mesh>
      
      {/* Main road */}
      <Road position={[0, 0, -90]} length={200} />
      
      {/* Buildings */}
      {buildings.map((building, i) => (
        <Building key={i} {...building} />
      ))}
      
      {/* Street lights */}
      {streetLights.map((pos, i) => (
        <StreetLight key={i} position={pos} />
      ))}
      
      {/* Neon signs */}
      {neonSigns.map((sign, i) => (
        <NeonSign key={i} {...sign} />
      ))}

      {/* Interactive Holograms */}
      {holograms.map((hologram, i) => (
        <InteractiveHologram 
          key={i} 
          {...hologram}
          onClick={() => onSectionClick?.(hologram.sectionIndex)}
        />
      ))}

      {/* Flying Drones */}
      <FlyingDrone startPosition={[-10, 15, -30]} color="#00ffff" />
      <FlyingDrone startPosition={[10, 20, -60]} color="#ff00ff" />
      <FlyingDrone startPosition={[0, 18, -100]} color="#ff6600" />
      <FlyingDrone startPosition={[-15, 25, -130]} color="#00ff66" />

      {/* Data Streams */}
      {[-20, -50, -80, -120, -150].map((z, i) => (
        <DataStream key={i} startZ={z} color={['#00ffff', '#ff00ff', '#ff6600', '#00ff66', '#ffff00'][i % 5]} />
      ))}
      
      {/* Floating particles */}
      <Particles count={400} />
      
      {/* Ambient fog light sources */}
      <pointLight position={[0, 20, 0]} color="#00d4ff" intensity={0.5} distance={100} />
      <pointLight position={[0, 20, -60]} color="#ff00ff" intensity={0.3} distance={80} />
      <pointLight position={[0, 20, -120]} color="#00ffff" intensity={0.3} distance={80} />
    </group>
  )
}
