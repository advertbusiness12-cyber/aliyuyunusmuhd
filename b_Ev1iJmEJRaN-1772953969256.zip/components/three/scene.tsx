'use client'

import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { CityScene } from './city-scene'
import { CameraController } from './camera-controller'

interface SceneProps {
  scrollProgress: number
  currentSection: number
  onSectionClick?: (section: number) => void
}

export function Scene({ scrollProgress, currentSection, onSectionClick }: SceneProps) {
  return (
    <div className="fixed inset-0 w-full h-full">
      <Canvas
        camera={{ fov: 60, near: 0.1, far: 500, position: [0, 8, 15] }}
        shadows
        gl={{ 
          antialias: true, 
          alpha: false,
          powerPreference: 'high-performance'
        }}
        dpr={[1, 2]}
      >
        {/* Fog for depth */}
        <fog attach="fog" args={['#050510', 10, 120]} />
        
        {/* Sky color */}
        <color attach="background" args={['#050510']} />
        
        {/* Lighting */}
        <ambientLight intensity={0.15} color="#88ccff" />
        <directionalLight
          position={[10, 30, 10]}
          intensity={0.3}
          color="#ffffff"
          castShadow
          shadow-mapSize={[2048, 2048]}
          shadow-camera-far={100}
          shadow-camera-left={-50}
          shadow-camera-right={50}
          shadow-camera-top={50}
          shadow-camera-bottom={-50}
        />
        
        {/* Accent lights */}
        <pointLight position={[-20, 15, -30]} color="#ff00ff" intensity={0.5} distance={60} />
        <pointLight position={[20, 15, -60]} color="#00ffff" intensity={0.5} distance={60} />
        <pointLight position={[0, 10, -100]} color="#ff6600" intensity={0.4} distance={50} />
        
        <Suspense fallback={null}>
          <CityScene onSectionClick={onSectionClick} />
          <CameraController scrollProgress={scrollProgress} currentSection={currentSection} />
        </Suspense>
      </Canvas>
    </div>
  )
}
