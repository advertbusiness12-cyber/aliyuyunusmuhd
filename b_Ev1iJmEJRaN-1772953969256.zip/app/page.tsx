'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import dynamic from 'next/dynamic'
import { AnimatePresence, motion } from 'framer-motion'
import { LoadingScreen } from '@/components/ui/loading-screen'
import { CustomCursor } from '@/components/ui/custom-cursor'
import { Navigation } from '@/components/ui/navigation'
import { PSController } from '@/components/ui/ps-controller'
import { VoiceNarration } from '@/components/ui/voice-narration'
import { IntroSection } from '@/components/sections/intro-section'
import { AboutSection } from '@/components/sections/about-section'
import { ProjectsSection } from '@/components/sections/projects-section'
import { SkillsSection } from '@/components/sections/skills-section'
import { ContactSection } from '@/components/sections/contact-section'

// Dynamically import 3D scene to avoid SSR issues
const Scene = dynamic(() => import('@/components/three/scene').then((mod) => mod.Scene), {
  ssr: false,
  loading: () => null,
})

const SECTION_COUNT = 5
const SECTION_NAMES = ['Intro', 'About', 'Projects', 'Skills', 'Contact']
const STORAGE_KEY = 'portfolio_session'
const SESSION_EXPIRY = 24 * 60 * 60 * 1000 // 24 hours

interface SessionData {
  currentSection: number
  voiceEnabled: boolean
  timestamp: number
  hasVisited: boolean
}

function getStoredSession(): SessionData | null {
  if (typeof window === 'undefined') return null
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (!stored) return null
    
    const data: SessionData = JSON.parse(stored)
    
    // Check if session has expired
    if (Date.now() - data.timestamp > SESSION_EXPIRY) {
      localStorage.removeItem(STORAGE_KEY)
      return null
    }
    
    return data
  } catch {
    return null
  }
}

function saveSession(data: Partial<SessionData>) {
  if (typeof window === 'undefined') return
  
  try {
    const existing = getStoredSession()
    const newData: SessionData = {
      currentSection: data.currentSection ?? existing?.currentSection ?? 0,
      voiceEnabled: data.voiceEnabled ?? existing?.voiceEnabled ?? false,
      timestamp: Date.now(),
      hasVisited: true,
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData))
  } catch {
    // Ignore storage errors
  }
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)
  const [currentSection, setCurrentSection] = useState(0)
  const [scrollProgress, setScrollProgress] = useState(0)
  const [isScrolling, setIsScrolling] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [isReturningUser, setIsReturningUser] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Restore session on mount
  useEffect(() => {
    const session = getStoredSession()
    if (session && session.hasVisited) {
      setCurrentSection(session.currentSection)
      setScrollProgress(session.currentSection / (SECTION_COUNT - 1))
      setVoiceEnabled(session.voiceEnabled)
      setIsReturningUser(true)
    }
  }, [])

  // Save session when section or voice changes
  useEffect(() => {
    if (!isLoading) {
      saveSession({ currentSection, voiceEnabled })
    }
  }, [currentSection, voiceEnabled, isLoading])

  // Handle loading complete
  const handleLoadingComplete = useCallback(() => {
    setIsLoading(false)
  }, [])

  // Navigate to a specific section
  const navigateToSection = useCallback((sectionIndex: number) => {
    const clampedIndex = Math.max(0, Math.min(sectionIndex, SECTION_COUNT - 1))
    setCurrentSection(clampedIndex)
    setScrollProgress(clampedIndex / (SECTION_COUNT - 1))
  }, [])

  // Toggle voice narration
  const toggleVoice = useCallback(() => {
    setVoiceEnabled(prev => !prev)
  }, [])

  // Handle scroll/wheel events for section navigation
  useEffect(() => {
    if (isLoading) return

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault()
      
      if (isScrolling) return

      const delta = e.deltaY
      const threshold = 50

      if (Math.abs(delta) > threshold) {
        setIsScrolling(true)
        
        if (delta > 0 && currentSection < SECTION_COUNT - 1) {
          navigateToSection(currentSection + 1)
        } else if (delta < 0 && currentSection > 0) {
          navigateToSection(currentSection - 1)
        }

        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current)
        }
        scrollTimeoutRef.current = setTimeout(() => {
          setIsScrolling(false)
        }, 1000)
      }
    }

    // Touch handling for mobile
    let touchStartY = 0
    
    const handleTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0].clientY
    }

    const handleTouchEnd = (e: TouchEvent) => {
      if (isScrolling) return

      const touchEndY = e.changedTouches[0].clientY
      const delta = touchStartY - touchEndY
      const threshold = 50

      if (Math.abs(delta) > threshold) {
        setIsScrolling(true)
        
        if (delta > 0 && currentSection < SECTION_COUNT - 1) {
          navigateToSection(currentSection + 1)
        } else if (delta < 0 && currentSection > 0) {
          navigateToSection(currentSection - 1)
        }

        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current)
        }
        scrollTimeoutRef.current = setTimeout(() => {
          setIsScrolling(false)
        }, 1000)
      }
    }

    // Keyboard navigation
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isScrolling) return

      if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault()
        if (currentSection < SECTION_COUNT - 1) {
          setIsScrolling(true)
          navigateToSection(currentSection + 1)
          scrollTimeoutRef.current = setTimeout(() => setIsScrolling(false), 1000)
        }
      } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
        e.preventDefault()
        if (currentSection > 0) {
          setIsScrolling(true)
          navigateToSection(currentSection - 1)
          scrollTimeoutRef.current = setTimeout(() => setIsScrolling(false), 1000)
        }
      } else if (e.key >= '1' && e.key <= '5') {
        e.preventDefault()
        const sectionIndex = parseInt(e.key) - 1
        navigateToSection(sectionIndex)
      }
    }

    window.addEventListener('wheel', handleWheel, { passive: false })
    window.addEventListener('touchstart', handleTouchStart, { passive: true })
    window.addEventListener('touchend', handleTouchEnd, { passive: true })
    window.addEventListener('keydown', handleKeyDown)

    return () => {
      window.removeEventListener('wheel', handleWheel)
      window.removeEventListener('touchstart', handleTouchStart)
      window.removeEventListener('touchend', handleTouchEnd)
      window.removeEventListener('keydown', handleKeyDown)
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current)
      }
    }
  }, [isLoading, isScrolling, currentSection, navigateToSection])

  // Handle 3D object clicks
  const handleSectionClick = useCallback((section: number) => {
    navigateToSection(section)
  }, [navigateToSection])

  return (
    <main ref={containerRef} className="relative w-full h-screen overflow-hidden bg-background">
      {/* Loading screen */}
      <AnimatePresence>
        {isLoading && (
          <LoadingScreen 
            onComplete={handleLoadingComplete}
            isReturningUser={isReturningUser}
          />
        )}
      </AnimatePresence>

      {/* Custom cursor (desktop only) */}
      <CustomCursor />

      {/* 3D Scene */}
      {!isLoading && (
        <Scene 
          scrollProgress={scrollProgress} 
          currentSection={currentSection}
          onSectionClick={handleSectionClick}
        />
      )}

      {/* Content sections */}
      {!isLoading && (
        <div className="relative z-10 w-full h-full pointer-events-none">
          <div className="pointer-events-auto">
            {/* Navigation */}
            <Navigation currentSection={currentSection} onNavigate={navigateToSection} />

            {/* Section indicator */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="fixed top-6 left-1/2 -translate-x-1/2 z-30"
            >
              <div className="glass px-4 py-2 rounded-full flex items-center gap-3">
                <span className="text-xs font-mono text-muted-foreground">SECTION</span>
                <span className="text-sm font-bold text-primary">{String(currentSection + 1).padStart(2, '0')}</span>
                <span className="text-muted-foreground">/</span>
                <span className="text-xs text-muted-foreground">{String(SECTION_COUNT).padStart(2, '0')}</span>
                <span className="hidden md:inline text-xs text-muted-foreground ml-2">
                  {SECTION_NAMES[currentSection]}
                </span>
              </div>
            </motion.div>

            {/* PS Controller Navigation */}
            <PSController 
              currentSection={currentSection}
              totalSections={SECTION_COUNT}
              onNavigate={navigateToSection}
            />

            {/* Sections */}
            <AnimatePresence mode="wait">
              {currentSection === 0 && (
                <IntroSection 
                  key="intro"
                  isActive={currentSection === 0} 
                  onScrollDown={() => navigateToSection(1)}
                />
              )}
              {currentSection === 1 && (
                <AboutSection 
                  key="about"
                  isActive={currentSection === 1} 
                />
              )}
              {currentSection === 2 && (
                <ProjectsSection 
                  key="projects"
                  isActive={currentSection === 2} 
                />
              )}
              {currentSection === 3 && (
                <SkillsSection 
                  key="skills"
                  isActive={currentSection === 3} 
                />
              )}
              {currentSection === 4 && (
                <ContactSection 
                  key="contact"
                  isActive={currentSection === 4} 
                />
              )}
            </AnimatePresence>

            {/* Voice Narration (optional) */}
            <VoiceNarration 
              currentSection={currentSection}
              isEnabled={voiceEnabled}
              onToggle={toggleVoice}
            />

            {/* Keyboard hints */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2 }}
              className="fixed bottom-6 left-6 z-30 hidden lg:flex items-center gap-4 text-xs text-muted-foreground"
            >
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 rounded glass text-primary">1-5</kbd>
                <span>Quick Nav</span>
              </div>
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 rounded glass text-primary">Space</kbd>
                <span>Next</span>
              </div>
            </motion.div>

            {/* Welcome back message for returning users */}
            <AnimatePresence>
              {isReturningUser && !isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: 1 }}
                  className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40"
                  onAnimationComplete={() => {
                    setTimeout(() => setIsReturningUser(false), 3000)
                  }}
                >
                  <div className="glass px-4 py-2 rounded-full text-sm text-primary">
                    Welcome back! Continuing from {SECTION_NAMES[currentSection]}...
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Transition overlay */}
      <AnimatePresence>
        {isScrolling && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-5 pointer-events-none bg-gradient-to-b from-background/20 via-transparent to-background/20"
          />
        )}
      </AnimatePresence>
    </main>
  )
}
