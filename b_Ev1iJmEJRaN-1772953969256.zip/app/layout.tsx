import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'Aliyu Yunus Muhammad | Web Developer Portfolio',
  description: 'Passionate web developer creating interactive, user-friendly applications. Specializing in full-stack development, real-time applications, and AI-powered solutions.',
  generator: 'v0.app',
  keywords: ['web developer', 'portfolio', 'full-stack', 'JavaScript', 'Python', 'Flask', 'chatbot', 'real-time applications'],
  authors: [{ name: 'Aliyu Yunus Muhammad' }],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  manifest: '/manifest.json',
  openGraph: {
    title: 'Aliyu Yunus Muhammad | Web Developer Portfolio',
    description: 'Passionate web developer creating interactive, user-friendly applications.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  themeColor: '#00d4ff',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background">
      <body className="font-sans antialiased overflow-x-hidden">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
